(function () {

        console.log("hola");
        alert("raiz");

}());
