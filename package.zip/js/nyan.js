
'use strict';
        console.log("hola");
        alert("raiz");

